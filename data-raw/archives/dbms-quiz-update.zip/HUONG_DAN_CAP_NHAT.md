# Cập nhật bộ câu hỏi "Nhà kho" – hướng dẫn ghép vào app

## 1. Chép file vào đúng chỗ
- `data/Nhà kho/*.json`  → ghi đè C1–C9.json cũ và thêm HOT.json (50 câu tủ, thực tế 49 vì thiếu câu 35).
- `assets/img/*.png`     → thư mục ảnh mới (công thức, đồ thị, cây CPT, bảng).
- Nếu `data/subjects.json` hoặc `scripts/parse-data.js` có liệt kê danh sách chương/file, thêm `HOT.json` (chapterId "HOT") vào đó.

## 2. Trường mới: `images`
Câu nào cần hình/công thức/bảng có thêm mảng `images` (đường dẫn tính từ thư mục gốc, cạnh index.html):
```json
{ "id": "HOT_Q36", "question": "...", "options": {...}, "correctAnswer": "B",
  "images": ["assets/img/pagerank_graph.png", "assets/img/eq_pagerank.png"] }
```
Câu không có hình thì không có trường này. Đề bài vẫn ghi sẵn dữ kiện dạng chữ (bảng giao dịch, các cạnh đồ thị...) nên nếu app chưa hiển thị ảnh thì vẫn làm được bài.

## 3. Hiển thị ảnh trong quiz.js (ví dụ)
Sau chỗ gán nội dung câu hỏi:
```js
if (Array.isArray(q.images)) {
  q.images.forEach(src => {
    const img = document.createElement('img');
    img.src = src;
    img.className = 'q-image';
    questionEl.appendChild(img);   // questionEl = phần tử đang chứa đề bài
  });
}
```
CSS (style.css):
```css
.q-image { display:block; max-width:100%; margin:10px auto; background:#fff; border-radius:6px; }
```
Nếu `parse-data.js` kiểm tra schema nghiêm ngặt, cho phép thêm trường tùy chọn `images` (mảng chuỗi).

## 4. Đã thay đổi trong C1–C9 (so với bản cũ)
Thêm 16 câu mới (ID nối tiếp, không đổi ID cũ):
C1_T3_Q9, C2_T1_Q7, C3_T4_Q11, C3_T6_Q9, C4_T4_Q7, C4_T8_Q12–Q13, C5_T2_Q10, C5_T3_Q10–Q11, C6_T2_Q10–Q14, C8_T3_Q8.
Gắn `images` cho 14 câu cũ: C4_T8_Q3–Q5, C5_T1_Q12, C5_T1_Q14–Q18, C5_T3_Q8, C6_T2_Q1, Q4, Q5, Q9.
